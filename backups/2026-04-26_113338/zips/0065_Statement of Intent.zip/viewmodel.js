/* jshint maxerr: 10000 */
define([
	"jquery",
	"knockout",
	"vmBase",
	"integration",
	"notify",
	"user",
	"template/autosize.min",
	"template/jquery.maskedinput",
	"./liveViewModel.js",
	"package",
	"https://webapps.oaklandcc.edu/cdn/formUtils-v9.js",
	/*-- WARNING: Uncommenting the line of code below will allow you to use Etrieve Extenders on this form.
    Currently, Etrieve Extenders are only compatible with cloud based instances of Etrieve.
    If you are unsure if you can utilize Extenders, please contact your institution's Etrieve Administrator.*/
	"https://softdocscdn.etrieve.cloud/extenders/extenders.min.js"
], function viewmodel(
	$,
	ko,
	vm,
	integration,
	notify,
	user,
	autosize,
	maskedinput,
	liveVM,
	pkg,
	formUtils
) {
	// Form-scoped required indicators manager.
	// Safe to call before init. Calls to setRequired(...) queue until afterLoad runs init(vm).
	var requiredIndicators = formUtils.createRequiredIndicators();

	function generateFormID() {
		const characters =
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*-_+=[]{}|;:,";
		let id = "";

		for (let i = 0; i < 10; i++) {
			const randomIndex = Math.floor(Math.random() * characters.length);
			id += characters[randomIndex];
		}

		return id;
	}

	// // Checking Source Data
	// integration.all('Web_Ethos_Get_Person_by_GUID', {
	//     personGUID:'aed6c606-a58c-44e4-a2b5-6b71ac490819'
	// }).then(function (data) {
	//     console.log('HERE', data);
	// });

	//add observable array for programs dropdown
	vm.addObservableArray("programsDropdown");
	vm.addObservableArray("studentCourseReg");
	//This function is used to set the autosize function on textareas with a class of autosizeareas.
	//Uncomment to use.
	//autosize($('.autosizeareas'));

	$(".developer").hide();

	/*
    These functions are used to set the masking of fields. There are 3 example classes below you can use.
    If you need to add another row, simple copy one of the examples below and edit the class name and the mask
    */
	$(".maskphone").mask("(999)999-9999? ext:9999");
	$(".maskzip").mask("99999?-9999");
	$(".maskssn").mask("999-99-9999");
	/*End masking functions*/

	//Parameters:
	//  $: jQuery object. Additional documentation found at api.jquery.com

	//  ko: knockoutjs object. Additional documentation found at knockoutjs.com

	//  vm: is a base viewmodel object that enables you to interact with observable inputs on the
	//  view.html.  Observables for all inputs, selects, and textareas will be added when the
	//  viewmodel is bound to the view.  vmBase has functions to aid in adding additional observable
	//  properties to itself such as addObservables, addObservableArrays which both take a comma-
	//  separated string of names.

	//  user: The user parameter includes data associated with the current user including isInLibrary,
	//  isInDrafts, isInActivity, isOriginator, DisplayName, UserName, hasGroupOrRole, Email.

	//  integration: has functions for directly calling integration sources configured on the server
	//  integration.first: takes Source Code and an optional Parameter Object, returning a single object
	//  integration.all: takes Source Code and an optional Parameter Object, returning an array of objects
	//  integration.add: takes Source Code and a Parameter Object, returning an array of objects
	//  integration.update: takes Source Code and a Parameter Object, returning an array of objects
	//  integration.delete: takes Source Code and a Parameter Object, returning an array of objects

	//  notify: method that display a toast notification, it requires the next parameters
	//      - toastrType: string indicating the type of toast notification, could have the next values:
	//          - success
	//          - warning
	//          - error
	//      - message: string indicating the message to display on notification
	//      - title: string indicating the title for the notification

	//  pkg: The pkg viewmodel object includes parameters which return properties
	//  around the package and the package state throughout the workflow.
	//  stepCode, stepName, isAtStep, isExporting.

	//The following methods are lifecycle callbacks that will be called as described
	//if they are returned on the viewmodel object, but they are not required.

	//NOTE: if a JavaScript Promise is returned from any Lifecycle Callback, the process will wait until
	//the Promise is resolved before continuing.  Additionally, if an Integration source or any other
	//asynchronous method is called directly within one of these functions, it is required that a Promise
	//be returned in order to guarantee these methods are called in a predictable, sequential manner.

	//Loading Lifecycle Callbacks:
	//Parameters:
	//  source:
	//  If the form is configured to receive integration sources onLoad or onOrigination,
	//  they will be passed on the source parameter. onLoad sources will be available
	//  every time the form is loaded while onOrigination sources will only be available
	//  when user.isInLibrary is true.

	//  inputValues:
	//  inputValues.first(id) takes an input id & returns a single value if one exists.
	//  inputValues.all(id) takes an input id & returns an array of values if any exist.
	//  inputValues.audit(id) takes an input id & returns an array of audit history values if any exist.
	//  inputValues.list is an array of all values sent from the server that will be loaded
	//      into this form after setDefaults and prior to afterLoad.  This should only be needed if
	//      it is necessary to filter on something other than input id.

	//GLOBAL VARIABLES
	let isThereCourseSelectedTerm = false;

	vm.onLoad = function onLoad(source, inputValues) {
		//  This takes place after applyBindings has been called and has added input observables to the
		//  viewmodel (vm) and before values are loaded into the form.  This method is ideal for
		//  populating dropdowns, select options and other operations that need to take place every
		//  time the form is loaded.

		//  WARNING: It is not recommended to set input values during onLoad because it is not guaranteed
		//  to save values to the server.

		updateSemesterCode();
	};
	vm.setDefaults = function setDefaults(source, inputValues) {
		//  This method is called after values from the server are loaded into the form inputs and before
		//  afterLoad is called.

		//  WARNING: if an integration source is called directly to retrieve values and populate inputs
		//  with default values, setDefaults must return the integration source promise.  If it doesn't,
		//  a form draft may be created every time a user opens the form and more importantly the values
		//  may not be saved to the server.

		integration
			.all("EthosColleagueAcademicPrograms", {})
			.then(function (programInfo) {
				console.log(
					"Programs from Ethos:",
					programInfo.sort((a, b) => a.title.localeCompare(b.title))
				); // Sorting by title);
				// List of program codes to exclude
				const excludedCodes = [
					"DHY.AASX",
					"DMS.AASX",
					"NUR.AAS",
					"RAL.AASX",
					"RSP.AASX",
					"SUR.AASX",
					"MTA",
					"PROG",
					"PLG.AAS"
				];

				const activePrograms = programInfo
					.filter(
						(program) =>
							program.status === "active" &&
							!excludedCodes.includes(program.code) &&
							!program.code.startsWith("NCP.")
					)
					.map((program) => ({
						title: program.title,
						code: program.code
					}))
					.sort((a, b) => a.title.localeCompare(b.title)); // Sorting by title

				vm.programsDropdown(activePrograms);
				console.log("Programs Dropdown: ", vm.programsDropdown());
			});

		vm.term.subscribe(function (newValue) {
			// term changed, let's clear out the dynamic list table.
			vm.courseTable().forEach(function (courseRow) {
				courseRow.sectionNumber("");
				courseRow.courseCode("");
				courseRow.courseName("");
				courseRow.creditHours("");
			});
			// and delete all rows from the table
			vm.courseTable.removeAll();

			if (newValue) {
				let [year, season] = newValue.split("/"); // Split the term into year and season
				let startYear = parseInt(year, 10); // Parse the year part as an integer
				let academicYear;

				// Determine the academic year based on the term season
				if (season === "FA") {
					// Fall is part of the next academic year cycle
					academicYear = `${startYear}-${(startYear + 1).toString().slice(-2)}`;
				} else if (
					season === "WI" ||
					season === "SU" ||
					season === "AY"
				) {
					// Winter and Summer are part of the current academic year cycle
					academicYear = `${startYear - 1}-${startYear.toString().slice(-2)}`;
				} else {
					// Handle unexpected input
					academicYear = "Invalid term";
				}

				// Update the academicYear observable
				vm.academicYear(academicYear);
				//filter just the courses from studentCourseReg for the selected term
				let matchingCourses = vm
					.studentCourseReg()
					.filter((c) => c.registrationTerm === newValue);

				// If no matches are found, send a notification
				if (matchingCourses.length === 0) {
					notify(
						"error",
						"No registered course found for the selected term."
					);
					isThereCourseSelectedTerm = false;
					return; // Exit early as there's nothing to process
				} else {
					isThereCourseSelectedTerm = true;
				}

				//loop through the courses for the term and populate the fields in the dynamic list
				matchingCourses.forEach(function (regByTermRow, i) {
					if (regByTermRow.registrationTerm == newValue) {
						vm.courseTable.push({});

						vm.courseTable()[i].sectionNumber(
							regByTermRow.registrationSectionNumber
						);
						vm.courseTable()[i].courseCode(
							regByTermRow.registrationCourseCode
						);
						vm.courseTable()[i].courseName(
							regByTermRow.registrationCourseName
						);
						vm.courseTable()[i].creditHours(
							regByTermRow.registrationCredits
						);
					}
				});
			}
		});

		vm.signature.subscribe(function (newValue) {
			if (newValue) {
				vm.signatureDate(Extenders.utils.formatDate(new Date()));
			} else {
				vm.signatureDate("");
			}
		});

		$("#semester, #year").on("change", updateSemesterCode);

		//Making fields readonly after the Start step
		if (!pkg.isAtStep("Start")) {
			$("#address, #city, #zipCode, #telephone").prop("readonly", true);
			$("#state")
				.prop("readonly", true)
				.attr({ tabindex: "-1", "aria-disabled": "true" })
				.css({
					pointerEvents: "none",
					backgroundColor: "#f5f5f5",
					color: "#555"
				});
			$("#currentlyActiveDutyCheck, #fedTuitionAssistCheck").prop(
				"disabled",
				true
			);
		}
		if (user.isInLibrary) {
			//  Input Values set here will be saved to the server when the user makes a form
			//  instance creating action: changing an input value or clicking submit.

			vm.formID(generateFormID());
			vm.vaDocType("Statement of Intent");

			//get all student information based on the colleague id
			integration
				.first("EthosColleagueStudentByErpId", {})
				.then(function (studentInfo) {
					console.log("Student Info: ", studentInfo);

					integration
						.all(
							"Web_Ethos_Get_Student_Programs_by_Student_GUID_V2",
							{
								studentID: studentInfo.id
							}
						)
						.then(function (academicProgram) {
							var activeAcademicProgram = "";
							console.log(
								"Student Academic Program:",
								academicProgram
							);

							academicProgram.forEach(function (program, index) {
								var status =
									program.enrollmentStatus.status.toLowerCase();

								if (status == "inactive") return;

								activeAcademicProgram = program;
								console.log(
									"PULLING ONLY ACTIVE PROGRAMS:",
									activeAcademicProgram
								);
							});

							if (!activeAcademicProgram)
								notify("error", "No active program found");

							var programGUID = activeAcademicProgram.program.id;
							console.log("Program GUID:", programGUID);

							integration
								.all(
									"Web_Ethos_Get_Academic_Program_by_program_GUID",
									{
										programID: programGUID
									}
								)
								.then(function (academicProgram) {
									console.log(
										"Academic Program Title:",
										academicProgram
									);
									console.log(
										"Academic Program Title:",
										academicProgram.title
									);
									vm.degreeProgram(academicProgram.title);
									vm.programCode(academicProgram.code);
								});
						});

					//get all the sections a student has registered for by student GUID
					integration
						.all("Web_Ethos_Section_Registration_by_Registrant", {
							personGUID: studentInfo.id
						})
						.then(function (registrationResults) {
							console.log(registrationResults);

							//start determining today - 365 days and formatting this date to match how the endOn value is being returned by Ethos
							const today = new Date();
							const oneDayInMilliseconds = 24 * 60 * 60 * 1000; // Number of milliseconds in a day
							const daysToSubtract = 365;
							const resultDate = new Date(
								today.getTime() -
									daysToSubtract * oneDayInMilliseconds
							);
							const formattedDate = resultDate.toISOString();
							const formattedDateOnly = formattedDate.substring(
								0,
								10
							);
							const concatDate =
								formattedDateOnly + "T00:00:00:-04:00";
							//console.log(concatDate);

							var p = []; //this our promise array

							//create a new array of registered courses from the last year
							registrationResults.forEach(
								function (registrationSection, index) {
									if (
										registrationSection.status
											.registrationStatus ==
											"registered" &&
										registrationSection.involvement.endOn >=
											concatDate
									) {
										p.push(
											integration.all(
												"Web_Ethos_Get_Sections_by_Section_ID",
												{
													sectionsGUID:
														registrationSection
															.section.id
												}
											)
										);
									}
								}
							);
							Promise.all(p).then(function (sectionResults) {
								//console.log(sectionResults);

								// Initialize an empty array to store matching results
								const SectionRegistration = [];

								// Loop through registrationResults and sectionResults
								for (const regResult of registrationResults) {
									for (const secResult of sectionResults) {
										if (
											regResult.section.id ===
											secResult.id
										) {
											// Extract desired information
											const regStatus =
												regResult.status
													.registrationStatus;
											const regGUID = regResult.id;
											const endDate = secResult.endOn;
											const term = secResult.termCode;
											const section = secResult.code;
											const instructorName =
												secResult.instructorFirstName +
												" " +
												secResult.instructorLastName;
											const location = secResult.site.id;
											const sectionID = secResult.id;
											const sectionNumber =
												secResult.number;
											const courseName =
												secResult.titles[0].value;
											const credits =
												secResult.credits[0].minimum;

											// Create an object with extracted information
											const matchingEntry = {
												regStatus,
												regGUID,
												endDate,
												term,
												section,
												instructorName,
												location,
												sectionID,
												sectionNumber,
												courseName,
												credits
											};

											// Push to SectionRegistration array
											SectionRegistration.push(
												matchingEntry
											);
										}
									}
								}

								//console.log('Section Reg Array: ', SectionRegistration);
								SectionRegistration.forEach(function (Results) {
									vm.studentCourseReg.push({
										registrationTerm: Results.term,
										registrationCourseCode: Results.section,
										registrationSectionNumber:
											Results.sectionNumber,
										registrationCourseName:
											Results.courseName,
										registrationCredits: Results.credits
									});
								});
								console.log(
									"studentCourseReg",
									vm.studentCourseReg()
								);
							});
						});
				});
		} else {
			//  Input Values set here will be saved to the server immediately.
			//  CAUTION: It is recommended to only set the values of inputs that haven't been populated by
			//  prior users.  Inputs that already have values saved to the server will be overridden with
			//  values set in this method.
		}
	};

	vm.afterLoad = function afterLoad() {
		//  This method is called after setDefaults has been called.

		//  WARNING: It is not recommended to set input values during afterLoad because it is not guaranteed
		//  to save values to the server.

		//Initialize FormBuilder created form specific code
		liveVM.afterLoadEditsForVM();

		// Initialize required indicators after VM bindings and form DOM are ready.
		// This replays any queued setRequired(...) calls made earlier in setDefaults.
		requiredIndicators.init(vm);

		ko.computed(function () {
			if (vm.semester() && vm.year()) {
				let semesterCode = vm.semester().slice(0, 2);
				let year = vm.year();
				vm.term(year + "/" + semesterCode);
			} else {
				vm.term("");
			}
		});

		/*
        //  This is resizing the textarea's when the form loads incase it is pulling in real data.
        var ta = document.querySelector('.autosizeareas');
        var evt = document.createEvent('Event');
        evt.initEvent('autosize:update', true, false);
        ta.dispatchEvent(evt);
        */
		autosize($("textarea"));
	};

	//Submitting Lifecycle Callbacks:
	//Parameters:
	//  form.attachmentCount: integer

	//In order to stop the Submitting Lifecycle and prevent this form from moving to the next step in the workflow
	//process, add the following to any of the functions below:
	//    throw new Error('reason placed here will be displayed to the user');

	vm.onSubmit = function onSubmit(form) {
		//  This method is called when the Submit button is clicked and before calling beforeRequired.
		//  This normally occurs in the Forms Library, but may occur in the Inbox when a package is
		//  returned to Originator.
	};

	vm.onApprove = function onApprove(form) {
		//  This method is called when the Approve button is clicked and before calling beforeRequired.
	};

	vm.onDecline = function onDecline(form) {
		//  This method is called when the Decline button is clicked and before calling beforeRequired.
	};

	vm.beforeRequired = function beforeRequired(form) {
		//  This method is called after onSubmit, onApprove or onDecline and before validating the forms required fields.
		// Enable native DOM `required` attributes at validation time.
		// This prevents fields from appearing invalid on initial load,
		// while still allowing browser validation during submit.
		requiredIndicators.applyNativeRequiredForValidation();
	};

	vm.afterRequired = function afterRequired(form) {
		//  This method is called after the required inputs on the form have been confirmed to have values.

		requiredIndicators.clearNativeRequired();

		if (pkg.isAtStep("Start")) {
			if (isThereCourseSelectedTerm === false) {
				throw new Error(
					"No registered course found for the selected term."
				);
			}
		}
	};

	vm.onOptOut = function onOptOut(form) {
		//  This method is called after the required inputs on the form have been confirmed to have values.
	};

	vm.onESignSubmit = function onESignSubmit(form) {
		//  This method is called after the required inputs on the form have been confirmed to have values.
	};

	//HELPER FUNCTION
	function updateSemesterCode() {
		const semester = $("#semester").val(); // e.g., "WINTER"
		const year = $("#year").val(); // e.g., "2026"

		if (!semester || !year) return;

		const semesterMap = {
			WINTER: "WI",
			SUMMER: "SU",
			FALL: "FA"
		};

		const semesterAbbrev = semesterMap[semester];
		if (!semesterAbbrev) return;

		const yearCode = year.toString().slice(-2);
		const termCode = `${semesterAbbrev}${yearCode}`;

		if (typeof vm !== "undefined" && typeof vm.semesterDEV === "function") {
			vm.semesterDEV(termCode);
		} else {
			$("#semesterDEV").val(termCode); // fallback
		}
	}

	return vm;
});
