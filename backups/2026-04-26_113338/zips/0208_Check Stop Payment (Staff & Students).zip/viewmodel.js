define(['jquery',
    'knockout',
    'vmBase',
    'integration',
    'notify',
    'user',
    'template/autosize.min',
    'template/jquery.maskedinput',
    './liveViewModel.js',
    'package',
    /*-- WARNING: Uncommenting the line of code below will allow you to use Etrieve Extenders on this form.
    Currently, Etrieve Extenders are only compatible with cloud based instances of Etrieve.
    If you are unsure if you can utilize Extenders, please contact your institution's Etrieve Administrator.*/
     'https://softdocscdn.etrieve.cloud/extenders/extenders.min.js'
], function viewmodel($, ko, vm, integration, notify, user, autosize, maskedinput, liveVM, pkg) {


    $('.maskphone').mask('(999)999-9999? ext:9999');
    $('.maskzip').mask('99999?-9999');
    $('.maskssn').mask('999-99-9999');
    $('.maskid').mask('9999999');
    /*End masking functions*/


    function payeeReadOnlyFields(){
        $("#originatorDisplayName").prop("disabled", true);
        $("#originatorErpId").prop("disabled", true);
        $("#originatorEmail").prop("disabled", true);
        
        $("#reasonForStop").attr("disabled", "disabled");
        $("#ddCheckType").attr("disabled", "disabled");
        $("#returnDetails").prop("disabled", true);
        $("#nameOnCheck").prop("disabled", true);
        $("#chkAcknowledge").prop("disabled", true);
    }
    
    function voucherInfoReadOnlyFields(){
        $("#voucherNumber").prop("disabled", true);
        $("#voucherDate").prop("disabled", true);
        $("#checkAmount").prop("disabled", true);
        $("#checkNumber").prop("disabled", true);
        $("#checkDate").prop("disabled", true);
    }

    vm.onLoad = function onLoad(source, inputValues) {
       $('.developer').hide();
    };
    
    vm.setDefaults = function setDefaults(source, inputValues) {

        //used for email template for both check stop pay forms
        vm.displayName(vm.originatorDisplayName());                
        
        vm.bankServSign.subscribe(newValue => {
            if (newValue) {
                vm.bankServSignDate(Extenders.utils.formatDate(new Date()));                
            } else {
                vm.bankServSignDate('');
            }
        });

        //Payroll (Payroll)     Student Refund (AR)    Vendor/Employee Reimbursement (AP)
        vm.ddCheckType.subscribe(newValue => {
            if (newValue) {
              if (newValue == 'Payroll (Payroll)') vm.checkType('payroll');
              if (newValue == 'Student Refund (AR)') vm.checkType('ar');
              if (newValue == 'Vendor/Employee Reimbursement (AP)') vm.checkType('ap');
            }
        });

        if (pkg.isAtStep('Start')){
            $('.voucherInfo').hide(); 
            $('.bankService').hide();
            $('.apManager').hide();
            $('.checkReissue').hide();
        }

        if (pkg.isAtStep('CheckStopPayroll') || pkg.isAtStep('CheckStopAP') || pkg.isAtStep('CheckStopAR')){
            payeeReadOnlyFields();
            $('.voucherInfo').show();

            $('.bankService').hide();
            $('.apManager').hide();
            $('.checkReissue').hide();
        }

        if (pkg.isAtStep('BankingService')){
            payeeReadOnlyFields();
            voucherInfoReadOnlyFields();
            
            //WF-FS Check Stop (AP/AR/Payroll)
            $('.voucherInfo').show();
            
            //WF-FS Banking Service
            $('.bankService').show();
            $("#bankServSign").prop("disabled", false);
            $('.checkReissue').hide();
            
            $('.apManager').hide();
               
        }
        
        //Only routes here if checkType = Payroll
        if (pkg.isAtStep('CheckStopPayrollChkReissue')){
            payeeReadOnlyFields();
            voucherInfoReadOnlyFields();
            
            //WF-FS Check Stop (AP/AR/Payroll)
            $('.voucherInfo').show();
            
            //WF-FS Banking Service
            $('.bankService').show();
            $("#bankServSign").prop("disabled", true);
            $("#hasBankConfirmed").attr("disabled", "disabled");
            
            $('.checkReissue').show();
            $("#checkReissue").attr("disabled", false);
            $("#reason").prop("disabled", false);
            
            $('.apManager').hide();
               
        }
        
        if (pkg.isAtStep('APManager')){
            payeeReadOnlyFields();
            voucherInfoReadOnlyFields();
            
            
            //WF-FS Check Stop (AP/AR/Payroll)
            $('.voucherInfo').show();

            //WF-FS Banking Service
            $('.bankService').show();
            $("#bankServSign").prop("disabled", true);
            $("#hasBankConfirmed").prop("disabled", true);
            
            $('.checkReissue').show();
            $("#checkReissue").attr("disabled", "disabled");
            $("#reason").prop("disabled", true);
            
            //WF-FS AP Manager
            $('.apManager').show();

        }

        if (user.isInLibrary) {

        } else {

        }
    };

    vm.afterLoad = function afterLoad() {
        liveVM.afterLoadEditsForVM();

        autosize($('textarea'));
    };

    vm.onSubmit = function onSubmit(form) {
        
    };

    vm.onApprove = function onApprove(form) {
       if (pkg.isAtStep('CheckStopAP') || pkg.isAtStep('CheckStopAR')){
            $("#voucherNumber").prop("required", true);
            $("#voucherDate").prop("required", true);
            $("#checkAmount").prop("required", true);
            $("#checkNumber").prop("required", true);
            $("#checkDate").prop("required", true);
            $("#checkStopSign").prop("required", true);
        }
        
        if (pkg.isAtStep('CheckStopPayroll')){
            $("#checkAmount").prop("required", true);
            $("#checkNumber").prop("required", true);
            $("#checkDate").prop("required", true);
            $("#checkStopSign").prop("required", true);
        }

        if (pkg.isAtStep('BankingService')) {
            $("#bankServSign").prop("required", true);
        }
        
        //CheckStopPayrollChkReissue
        if (pkg.isAtStep('CheckStopPayrollChkReissue')){
           $("#checkReissue").attr("required", "required");
           let option = $("#checkReissue option:selected").text();
           if (option.trim() == "No" && $("#reason").val() == "") {
              notify('error','Reason is required when selecting check has not been re-issued');
              return false;
           }
        }
        
        if (pkg.isAtStep('APManager')) {
           $("#FSNotes").prop("required", true);
           
            if (!$("#voidedCheckOnly").is(":checked") && !$("#voidedCheckAndVoucher").is(":checked")) {
              notify("error", "You must make a selection between check only or check and voucher");
              return false;
            }
        }
    };

    vm.onDecline = function onDecline(form) {
       if (pkg.isAtStep('CheckStopPayroll') || pkg.isAtStep('CheckStopAP') || pkg.isAtStep('CheckStopAR')) {
         $("#voucherNumber").prop("required", false);
         $("#voucherDate").prop("required", false);
         $("#checkAmount").prop("required", false);
         $("#checkNumber").prop("required", false);
         $("#checkDate").prop("required", false);
         $("#checkStopSign").prop("required", false);
       }
       
       if (pkg.isAtStep('BankingService')) {
        $("#bankServSign").prop("required", false);
       }
    
       if (pkg.isAtStep('APManager')) {
        $("#FSNotes").prop("required", false);

       }
    };

    vm.beforeRequired = function beforeRequired(form) {

    };

    vm.afterRequired = function afterRequired(form) {

    };

     vm.onOptOut = function onOptOut(form) {

    };

    vm.onESignSubmit = function onESignSubmit(form) {

    };

    return vm;
});
