define([
	'../293/requiredIndicators.js',
	'../293/autoCompleteUtils.js'
], function () {
	"use strict";

	console.log("formUtils v20260504 loaded");

	if (typeof window.createRequiredIndicators !== "function") {
		throw new Error("requiredIndicators.js did not load correctly.");
	}

	if (typeof window.createAutoCompleteUtils !== "function") {
		throw new Error("autoCompleteUtils.js did not load correctly.");
	}

	return {
		createRequiredIndicators: window.createRequiredIndicators,
		createAutoCompleteUtils: window.createAutoCompleteUtils
	};
});
